package dk.itu.openjml.quantifiers;

import java.util.Iterator;

/**
 * A set of intervals over integers. The Interval is a
 * subtype of IntervalSet and can be regarded as a singleton
 * of IntervalSet.
 */
public abstract class IntervalSet implements Iterator<Integer>, Iterable<Integer>{

	protected /*@ nullable @*/ IntervalSet left;
	protected /*@ nullable @*/ IntervalSet right;
	private boolean initialized;
	protected int low;
	protected int high;
	protected int current;
	
	/**
	 * Cheap trick! But it works(TM) #18
	 * 
	 * Normally we would return new SomeIterator<Integer>().
	 * 
	 * @returns This, as it is also implements Iterator and for that
	 * reason full fills the interface.
	 */
	public Iterator<Integer> iterator() {
		return this;
	}
	
	/**
	 * Performs union on two IntervalSets
	 * @param l Left IntervalSet
	 * @param r Right IntervalSet
	 * @return An IntervalSet of type UnionIntervalSet
	 */
	//@ ensures \fresh(\result);
	public static IntervalSet union(IntervalSet l, IntervalSet r){
		return new UnionIntervalSet(l, r);
	}
	
	/**
	 * Performs intersection on two IntervalSets
	 * @param l Left IntervalSet
	 * @param r Right IntervalSet
	 * @return An IntervalSet of type IntersectionIntervalSet
	 */
	//@ ensures \fresh(\result);
	public static IntervalSet intersect(IntervalSet l, IntervalSet r){
		return new IntersectionIntervalSet(l, r);
	}
	
	/**
	 * Only factory that can produce an IntervalSet without two IntervalSets
	 * - both values are inclusive in the interval.
	 * 
	 * @param low The lower boundary
	 * @param high The upper boundary
	 * @return An IntervalSet of type Interval describing an interval over integers
	 */
	//@ ensures \fresh(\result);
	public static IntervalSet interval(int low, int high){
		return new Interval(low, high);
	}
	
	/**
	 * Internal constructor
	 * @param l Left side of the set
	 * @param r Right side of the set
	 */
	protected IntervalSet(/*@ nullable @*/ IntervalSet l, /*@ nullable @*/ IntervalSet r){
		left = l;
		right = r;
		current = Integer.MIN_VALUE;
		initialized = false;
	}
	
	//@ requires !initialized || current == high;
	//@ assignable low, high, current;
	//@ also
	//@ requires low <= current;
	//@ requires current < high;
	//@ ensures \result == true;
	//@ also
	//@ requires low > current || current >= high;
	//@ ensures \result == false;
	public boolean hasNext() {
		// Get the next valid range
		if(!initialized || current < high){
			initialized = true;
			getNextRange();
		}
		
		// This assures that false is returned if we reached
		// the end of the interval and the interval is right inclusive!
		if(low == current && high == current){
			return false;
		}
		
		return low <= current && current <= high;
	}

	public Integer next(){
		// Check sets up all the ranges, just in case
		if(hasNext()){
			return current++;
		}
		
		return current;
	}
	
	/**
	 * This is implemented because Iterator requires it.
	 */
	public void remove(){
        throw new UnsupportedOperationException();
	}
	
	/**
	 * Find the next valid range for this IntervalSet
	 */
	//@ ensures current == low;
	//@ assignable low, high, current;
	//@ ensures \old(current) <= current;
	protected void getNextRange(){
		low = getNextLow(current);
		high = getNextHigh(current);
		
		// Set current to the new low
		current = low;
	}
	
	/**
	 * Checks if a given number is inside this IntervalSet (inclusive)
	 * @param current The number to check against
	 * @return True if current is inside, false otherwise
	 */
	abstract protected boolean isInside(int current);
	
	//@ invariant initialized ==> isInside(current);
	
	/**
	 * Returns the next valid low after current
	 * @param current The current number active.
	 * @return The new low. If there is no valid new low, return current again.
	 */
	abstract protected /*@ pure @*/ int getNextLow(int current);
	
	/**
	 * Returns the next valid high for current 
	 * @param current
	 * @return
	 */
	abstract protected /*@ pure @*/ int getNextHigh(int current);
}

/**
 * Represents a union of two IntervalSets 
 */
class UnionIntervalSet extends IntervalSet {
	
	protected UnionIntervalSet(IntervalSet l, IntervalSet r){
		super(l, r);
	}
	
	//@ ensures \result == left.isInside(current) || right.isInside(current);
	protected /*@ pure @*/ boolean isInside(int current){ 
		return left.isInside(current) || right.isInside(current);
	}
	
	/**
	 * Union can answer two different lows!
	 */
	protected /*@ pure @*/ int getNextLow(int current){
		int l = left.getNextLow(current);
		int r = right.getNextLow(current);
		
		// If both are higher than current
		if(current < l && current < r){
			// Return the smaller low
			return l < r ? l : r;
		
		// Else return the one that is higher than current
		} else if(current < l){
			return l;
		} else if(current < r){
			return r;
		}
		
		// If none of this holds, return current again
		return current;
	}
	
	/**
	 * Union can answer two different highs!
	 */
	protected /*@ pure @*/ int getNextHigh(int current) {
		int l = left.getNextHigh(current);
		int r = right.getNextHigh(current);
		
		// If both are higher than current
		if(current < l && current < r){
			// Return the smaller high
			return l < r ? l : r;
		
		// Else return the one that is higher than current
		} else if(current < l){
			return l;
		} else if(current < r){
			return r;
		}
		
		// If none of this holds, return current again
		return current;
	}
}

/**
 * Represents an intersection of two IntervalSets 
 */
class IntersectionIntervalSet extends IntervalSet {
	
	protected IntersectionIntervalSet(IntervalSet l, IntervalSet r){
		super(l, r);
	}
	
	//@ ensures \result == left.isInside(current) && right.isInside(current);
	public /*@ pure @*/ boolean isInside(int current){
		return left.isInside(current) && right.isInside(current);
	}
	
	/**
	 * Intersection can only answer one low.
	 */
	protected /*@ pure @*/ int getNextLow(int current) {
		int l = left.getNextLow(current);
		int r = right.getNextLow(current);
		
		// When current is lower than any of these, return
		// the higher low.
		if(current < l || current < r){
			return l < r ? r : l;
		}
		
		// Else just return current
		return current;
	}
	
	/**
	 * Intersection can only answer one high.
	 */
	protected /*@ pure @*/ int getNextHigh(int current) {
		int l = left.getNextHigh(current);
		int r = right.getNextHigh(current);
		
		// When current is lower than any of these, return
		// the lower high.
		if(current < l || current < r){
			return l < r ? l : r;
		}
		
		// Else just return current
		return current;
	}
}

/**
 * Represents a singleton of IntervalSet
 * It is left-inclusive and right-exclusive!
 */
class Interval extends IntervalSet {
		
	/**
	 * Creates an actual left-inclusive right-exclusive interval
	 * @param low Lower boundary
	 * @param high Upper boundary
	 */
	//@ assignable left, right, low, high, current;
	//@ ensures left == null && right == null;
	protected Interval(int low, int high){
		super(null, null);
		this.low = low;
		this.high = high;
		this.current = this.low;
	}
	
	//@ ensures low <= current && current <= high;
	protected /*@ pure @*/ boolean isInside(int current){
		return low <= current && current <= high;
	}
	
	//@ ensures \result == isInside(current);
	public /*@ pure @*/ boolean hasNext(){
		return isInside(current);
	}
	
	//@ ensures \result == this.low;
	protected int getNextLow(int current) {
		return low;
	}
	
	//@ ensures \result == this.high;
	protected int getNextHigh(int current) {
		return high;
	}
}